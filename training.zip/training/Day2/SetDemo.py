"""
Random Storage = set random unique elements

"""

s1={}   #dict
#First way
s1={1,5,3,3,3,3} #set

print("Set : ",s1)
#print("Set : ",s1[0]) #TypeError: 'set' object is not subscriptable

#First way
s2=set([12,4,6,8,1])
print("Set : ",s2)  #Set :  {8, 12, 4, 6}

s2.add(10)
print("Set 2 after add(): ",s2)  #Set :  {8, 12, 4, 6}


for i in s2:
    print(i)

s3=s1|s2
print("Union S3: ",s3,"type",type(s3))

s4=s1&s2
print("Union S4: ",s4,"type",type(s4))  #Union S4:  {1} type <class 'set'>


