from mymath import *
print(area(10))
