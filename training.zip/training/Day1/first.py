print("Hello World");
#print("Welcome to persistent);#SyntaxError:EOL while scanning literal
print('Hiiiiiiiiiiiiiiiiii')

#print(num99);
"""
python raises an object Exception - NameError class
python interpreter catches/accepts that object
print error description and then  terminates the code
"""
num1=100;
num2=200;
pi=3.142
print(num1+pi)
s1="Sam"
#num1+s1
"""
Traceback (most recent call last):
  File "first.py", line 14, in <module>
    num1+s1
TypeError: unsupported operand type(s) for +: 'int' and 'str'
"""


"""
This is a multiline comment block
This is called as DocString-Documented String
indent codeblock required in 
	if elif else
	loops- for while
	functions
	class 
	Exception Handling

"""

if num1==100:
	print("if code block.......")
	print("Addition of num1: ",num1," and num2: ",num2," = ",num1+num2);
elif num1==200:
	print("elif code block.......")
print("Sa")

