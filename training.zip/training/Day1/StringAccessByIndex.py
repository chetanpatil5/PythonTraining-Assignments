"""
Sequence type: String Access by numerical index

"""

s1="abcde"
print("s1 = ",s1)
print("s1 first char = ",s1[0])
print("s1 last char= ",s1[-1])
print("s1[2:5] =",s1[2:5])  #slicing #234
print("s1[2:] =",s1[2:]) #2345
print("s1[:4] =",s1[:4] )#0123
print("s1[::-1] =",s1[::-1] )#54321
print("s1[:-1] =",s1[:-1] )#5
print("type(s1) = ",type(s1))
num1=100
print("type(num1) = ",type(num1))
pi=3.142
print("type(pi) = ",type(pi))
num2=num1+pi
print("type(num2) = ",type(num2))

s2="Chetan"
print(s2.lower())
s3=s2.lower()
print(s3.islower())
print(s3.isupper())
s4='1234f'
print(s4.isdigit())
print(s4.isalpha())
if type(s1)==str:
     upperstr=s1.upper()
     print("s1 = ",s1)
     print("upperstr= ",upperstr)

"""
upper lower isupper islower isalpha isdigit

"""
