import re
str1="Welcome to PSL."

str2="welcome to psl"
str3="Welcome to PSL PSL"

patternObj=re.compile("PSL")
print(str1) #Welcome to PSL.
print(patternObj) #re.compile('PSL')
matchObj=patternObj.search(str3)
print("MatchObj : ",matchObj)

if matchObj!=None:
    print("Match Found")
else:
    print("MatchNotFound")
