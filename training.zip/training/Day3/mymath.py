pi=3.14159
def area(r):
    global pi
    return(pi*r*r)

def fib(n):
    a,b=0,1
    while b<n:
        print(b)
        a,b=b,a+b
print("======"*25)
print(__name__)

if __name__ == "__main__":          #Running current program by its own
    fib(21)
    print(area(5))

print("======"*25)
