"""

Read file content of given file “empdata”, store it in dictionary.
Display all employee details by sorting employee ID’s.
1a:ABC:25:25000 (assume 1a as emp ID, ABC as name, 25 as age, 25000 as sal) and print total sal.

File data: (Create the file yourself empdata.txt)
1a:ABC:25:25000
2a:XYZ:30:30000
3a:LMN:45:60000

Hint--
Emp = {}  #in memeory data structure storage
FH =open(“file name”)
For line in FH:
	Line = line.rstrip()
	L1 = Line.split(“:”)   #[1a, ABC, 25, 25000]
	Emp[L1[0]]=l1[1:]


Emp ={‘1a’:[‘ABC’,25,25000]}


"""
Emp={}
fin=open("empdata.txt","r")
for line in fin:
    Line=line.rstrip()
    l1=Line.split(":")
    Emp[l1[0]]=l1[1:]
fin.close()

keyobject=Emp.keys()
l1=list(keyobject)
l1.sort()

for i in l1:
    print("Employee id: ",i,"Employee Details : ",Emp[i])

tot=0
for i in l1:
    tot+=int(Emp[i][2])
print("Total Salary of All employees is  : ",tot)
