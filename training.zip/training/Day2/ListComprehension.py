"""

list comprehension
dictionary comprehension

"""

list1=[10,20,30]
sqaurelist1 = [i**2 for i in list1]         #[100, 400, 900]
print(sqaurelist1)


sqaurelist1 = [i**2 for i in list1 if i<30]    
print(sqaurelist1)



list2=[1,2,3]
dict1={i:i**2 for i in list2}
print(dict1)
