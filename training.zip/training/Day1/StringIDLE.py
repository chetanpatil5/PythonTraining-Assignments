"""
Data Type Structures in Python

Sequence Types: String,Tuple,List
Random/Unordered : Set,Dictionary
String Quoataions : Single,Double,Triple quote string value
"""

s1='Ab\'c'
print(s1)


s2="AB\"C"
print(s2)


s3='xy"z'
print(s3)

s4="xy'z"
print(s4)

s5=""" a'b"c """
print(s5)

s6=''' a'b"c '''
print(s6)

s7='''
Welcome
                To
                        Persistent'''
print(s7)




