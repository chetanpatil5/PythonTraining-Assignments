"""
4.Accept 2 numbers from keyboard. Pass these as keyworded arguments and let function return the addition answer. 

"""

num1=int(input("Enter the first number "))
num2=int(input("Enter the second number "))

def Addition(a,b):
    print("a ",a)
    print("b ",b)
    return a+b

c=Addition(b=num2,a=num1)
print("Addition is : ",c)

