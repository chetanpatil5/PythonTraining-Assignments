"""
Acceptance of input
"""
num1=100;
if num1==100:
    print("Value matched")
elif num1==33:pass
else:
    print("Value did not")
    

s1="Hello"
print("s1 : ",s1);
print("id of s1",id(s1))

s1=s1+" World!"
print("s1 : ",s1);
print("id of s1",id(s1))

"""
s1 :  Hello
id of s1 1415565108656
s1 :  Hello World!
id of s1 1415564826288
"""
path1="c:\new\test.py"
print(path1)

path1=r"c:\new\test.py"
print(path1)

path1=R"c:\new\test.py"
print(path1)                       #c:\new\test.py

del path1
#print(path1)

"""
name=input('Enter your name : ')
print("Welcome : ",name)
print("Type of",name,"is :",type(name))

num1=input("Enter The first nos :")
num11=int(num1)
#casting the type of string to int

num2=input("Enter The second nos :")
num22=int(num2)
#casting the type of string(keyboard) to int

print("The Addition is :",num11+num22)


"""
