"""
Data Structure List

"""


list1=[123,"ABC",3.142]
print("list1 =  ",list1)
print("type of list1 =  ",type(list1))
print("id of list1 =  ",id(list1))

print("Second Element :",list1[1])

list2=[123,"ABC",3.142,[99,"XYZ"]]
print("list2 =  ",list2)
print("type of list2 =  ",type(list2))
print("id of list2 =  ",id(list2))
print("Inner list - ",list2[-1])
print("Inner list cha second element- ",list2[-1][1])       #list is mutable

list2.append(9999)  #return value of append is null
list2.append(["xyz",3])
print("list2 =  ",list2)
list1.insert(3,[45,55]) #list2 =   [123, 'ABC', 3.142, [99, 'XYZ'], 9999, ['xyz', 3]]
list1.extend([44,"ABC"])
print(list1)

print(list1.reverse())  #None
print(list1)                    #['ABC', 44, [45, 55], 3.142, 'ABC', 123]
