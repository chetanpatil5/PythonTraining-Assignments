import mymath#a file mymath.py will be searched
import math
print("_"*75)
print(mymath.area(6))
print(math.gamma)
