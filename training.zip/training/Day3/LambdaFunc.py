"""
Write a lambda return addition of two nos
Write a lambda to convert a string to  uppercase  
"""

print((lambda num1,num2:num1+num2)(5,5))
print((lambda str1:str1.upper() if type(str1)==str and str1.isalpha() else str1)("che"))
