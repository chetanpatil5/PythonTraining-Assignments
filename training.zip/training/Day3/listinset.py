
thisset={"che","mam",["sam","gaya"]}
print(thisset)

