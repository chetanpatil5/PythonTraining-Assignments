import re
#----------------------------------------------------------------
str1="Welcome to PSL."
str2="PSLwelcome to psl"
str3="Welcome to PSL PSL"

patternObj=re.compile("PSL")

#----------------------------------------------------------------
print(str1) #Welcome to PSL.
print(patternObj) #re.compile('PSL')
matchObj=patternObj.match(str2)
print("MatchObj : ",matchObj)

if matchObj!=None:
    print("Match Found")
else:
    print("MatchNotFound")


















    
"""
#for str1
Welcome to PSL.
re.compile('PSL')
MatchObj :  None
MatchNotFound

"""
"""
#for str2
Welcome to PSL.
re.compile('PSL')
MatchObj :  <re.Match object; span=(0, 3), match='PSL'>
Match Found
"""
