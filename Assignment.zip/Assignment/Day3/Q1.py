
fin =open("country.txt","r")

lang_country={}
for line in fin:
    l1=line.rstrip()
    list_words=l1.split(",")
    city_capital={}

    if list_words[-1] not in lang_country:
        city_capital[list_words[0]]=[list_words[2]]
        lang_country[list_words[-1]]=city_capital
    else:
        lang_country[list_words[-1]][list_words[0]]=[list_words[2]]
fin.close()
print(lang_country)
