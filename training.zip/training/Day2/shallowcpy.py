import copy #copy is a predefined library module

list1=[10,20,30]
print(list1)

print("--"*45)
newlist=list1 # this is a shallow copy -> both pointing to the same memory
print("id(list1) : ",id(list1))
print("id(newlist) : ",id(newlist))

list1.append(99)
print("id(list1) : ",id(list1))
print("id(newlist) : ",id(newlist))

print("--"*45)
newlist2=list1.copy()   # this is a deep copy -> both pointing to the different memory
print("id(list1) : ",id(list1))
print("id(newlist2) : ",id(newlist2))

print("^"*45)
list1.reverse()
print(list1)
print(newlist)
print(newlist2)

print("--"*45)
newlist3 = copy.deepcopy(list1)
print(newlist3)
print(id(newlist3))
print("--"*45)

newlist4=list1[:]
print("id(list1) : ",id(list1))
print("id(newlist4) : ",id(newlist4))

print("--"*45)
#Tuple
t1=(1)
t2=(2)
t3=t1+t2
print("t1 : ",t1,"t1 type : ",type(t1))
print("t2 : ",t2,"t2 type : ",type(t2))
print("t3 : ",t3,"t3 type : ",type(t3))

t1=(1,)
t2=(2,)
t3=t1+t2
print("t1 : ",t1,"t1 type : ",type(t1))
print("t2 : ",t2,"t2 type : ",type(t2))
print("t3 : ",t3,"t3 type : ",type(t3))


t4=(None,)
t5=1,2,3,4,5
emptytuple=tuple()
print("t5 : ",t5,"t5 type : ",type(t5))


