s1=input("Enter first number  :")
num1=int(s1)

s2=input("Enter first number  :")
num2=int(s2)

print("Addition is : ",num1+num2)
print("Subtraction is : ",num1-num2)
