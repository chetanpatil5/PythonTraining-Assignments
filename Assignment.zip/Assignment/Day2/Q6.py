"""

6.	Count of languages: 
Read Country.txt file
Store the Country data only for Language and its count in a dictionary.
Display the o/p in below 2 formats -
>>>
Portuguese 1
Franch 4
Chinese 1
Vietnamese 1
German 1
English 5
Japanese 1
Greek 1
Indian 1
Spanish 3
Arabic 2
Hungerian 1
Italian 1
------------------------------------------------------------------------------------------------------------------------------
{'Portuguese': 1, 'Franch': 4, 'Chinese': 1, 'Vietnamese': 1, 'German': 1, 'English': 5, 'Japanese': 1, 'Greek': 1, 'Indian': 1, 'Spanish': 3, 'Arabic': 2, 'Hungerian': 1, 'Italian': 1}
>>>


"""
from collections import Counter

dict1={}
l2=[]
fin=open("country.txt","r")
for line in fin:
    line=line.rstrip()
    l1=line.split(",")
    l2.append(l1[-1])


listofkeys=list(Counter(l2).keys())
listofvalue=list(Counter(l2).values())
print(listofkeys)
print(listofvalue)

for i  in range(0,len(listofkeys)):
    dict1[listofkeys[i]]=listofvalue[i]

print(dict1)
