inputstr=input("Enter the string :")
if inputstr=="psl" or inputstr=="PSL":
    print("Valid Password")
else:
    print("Invalid Password")
