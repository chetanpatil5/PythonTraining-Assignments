"""

1.	sort the list of following names by an ascending order of number of letters in each name 
unsortedList = ['Aaaa', 'bb', 'cccccccc', 'zzzzzzzzzzzz']

"""
unsortedList = ['Aaaa', 'bb', 'cccccccc', 'zzzzzzzzzzzz']
unsortedList.sort(key=len)

print("Names by an ascending order of number of letters are : ",unsortedList)
