"""
for loop
"""
list1=[1,2,3,4,5,6]

for i in list1:
    print(i)

#To get index of an element
print("range(5) : ",range(5) ) #range(0, 5)

r1=range(5)
newlistofrange=list(r1)
print("newlistofrange : ",newlistofrange)

list2=[1,2,3,4,5,6]
for i in range(len(list2)):
    print("Index :",i," list[",i,"] : ",list2[i])
    list2[i]**=2
print("list2 : ",list2)

list3=[0,1,2,3,4,5,6,7,8,9,10]
print(list3)
for i in range(0,len(list3),2):
    print(i)
    print(list3[i])
print("Hello")



