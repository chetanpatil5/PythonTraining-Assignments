empData = {'1a':['ABC',25,600.5] , '2a':['XYZ',25,65.655]}

print("Type of 1a : ",type(empData['1a']))
print("Info of 1a : ",empData['1a'])
print("Salary of 2a :",empData['2a'][2])

print("-"*70)
empData1={'1a':{'Name':'ABC','Age':25,'Salary':600.5} , '2a':{'Name':'XYZ','Age':20,'Salary':60.5}}
print("Type of 1a : ",type(empData1['1a']))
print("Info of 1a : ",empData1['1a'])
print("Name of 1a :",empData1['1a']['Name'])
print("Salary of 2a :",empData1['2a']['Age'])

print(empData1.values())
