"""
Dictionary: key-value pair storage
                    key should be unique
                    refer a key to find its value
                    key data should be immutable - str int float tuple
                    value could be anything - str int float tuple list

 3.
Define dictionary as
emp ={'1a':30000,'2a':40000}
a.	Accept employee details from user as 
str1 = raw_input("Enter emp ID:salaray in a single line: ")#"7a :77000"
and such multiple records  till user wishes.
b.	print all employee details in sorted keys order
c.	Increment the salary of every person by 5000 and then print the updated emp

"""

empData={
                    "1a":30000,
                    "2a":40000,
                  }
#print("Type of empData is : ",type(empData)) #Type of empData is :  <class 'dict'>
print("empData : ",empData)

while(True):
    str1=input("Enter Employee id and Salary")
    str1.rstrip()
    if(str1==""):break
    list1=str1.split(" ")   #["4a","50000"]
    empData[list1[0]]=int(list1[1])
    
   



keyobj=empData.keys()
list4=list(keyobj)
list4.sort()
print(list4)

for i in list4:
    print("Employee ID : ",i,"  Salary : ",empData[i])


#ITERATIONS
print("Incremented Salaries)
for i in empData:       #list4 can be replacad by empData #i by default traverses the key
    empData[i]+=5000
    print("Employee ID : ",i,"  Salary : ",empData[i])
    
