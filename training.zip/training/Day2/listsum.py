"""
list1=[13,25,3,4]
tot=0

for i in range(len(list1)):
    tot=sum(list1[i])
print(tot)
"""

list1=[1,66,100,999,89]
print("List : ",list1)
list1.sort()
print("List : ",list1)
list1.sort(reverse=True) #keyword argument passing
print("List : ",list1)  #List :  [999, 100, 89, 66, 1]
"""
#list1=[1,66,100,"abc",999,89]
#TypeError: '<' not supported between instances of 'str' and 'int'
print("List : ",list1)
list1.sort()
print("List : ",list1)
"""

words=["abcd","xyz","Persistent"]
words.sort(reverse=True)
print("Words : ",words)
words.sort(key=len)
print("Words : ",words) #sort by len #Words :  ['xyz', 'abcd', 'Persistent']
#inplace sorting where words list is changed

list2=[5,1,3,9]
newsortedlist2=sorted(list2)
print(list2)    #[5, 1, 3, 9]
print(newsortedlist2)   #[1, 3, 5, 9]
print(list2)        #[5, 1, 3, 9]


newsortedlist2=sorted(list2,reverse=True)
print(newsortedlist2)   #[9, 5, 3, 1]

#returns a reverse iterator object
list3=[5,99,55,44]
revitrobj=reversed(list3)
print("revitrobj : ",revitrobj)
print("reverseitrobj ka type",type(revitrobj))

revitrlist= list(revitrobj)
print(revitrlist)
