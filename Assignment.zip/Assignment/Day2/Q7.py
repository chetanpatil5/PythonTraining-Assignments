﻿"""
Store the Country data only for Language and its list of countries in a dictionary.
Display the o/p as shown below -
Write a function for this, store it in a module and access this in your final application.


o/p---

>>> 
{'Portuguese': ['Brazil'], 'Franch': ['Cameroon', 'Djibouti', 'Equatorial Guinea', 'France'], 'Chinese': ['China'], 'Vietnamese': ['Vietnam'], 'German': ['Germany'], 'English': ['United Kingdom', 'United States', 'Fiji', 'Canada', 'Ireland'], 'Japanese': ['Japan'], 'Greek': ['Greece'], 'Indian': ['India'], 'Spanish': ['Venezuela', 'Argentina', 'Honduras'], 'Arabic': ['Yemen', 'Bahrain'], 'Hungerian': ['Hungary'], 'Italian': ['Italy']}


"""
fin=open("country.txt","r")

lang_country={}

for line in fin:
    l1=line.rstrip()
    list_words=l1.split(",")

    if list_words[-1] not in lang_country:
        lang_country[list_words[-1]]=[list_words[0]]
    else:
        lang_country[list_words[-1]].append(list_words[0])

fin.close()
print(lang_country)
