"""
Dictionary: key-value pair storage
                    key should be unique
                    refer a key to find its value
                    key data should be immutable - str int float tuple
                    value could be anything - str int float tuple list
"""

empData={
                    "1a":2500,
                    "2a":3500,
                    "3a":4500
                  }
print("Type of empData is : ",type(empData)) #Type of empData is :  <class 'dict'>
print("empData : ",empData)

#print(empData[0]) #KeyError: 0
print(empData["1a"])
empData["1a"]+=5000
print(empData["1a"])

print(empData)

d3={
            "4a":50000
       }

str1=input("Enter Employee id and Salary")
str1.rstrip()
list1=str1.split(" ")   #["4a","50000"]
empData[list1[0]]=int(list1[1])
print(empData)


print(empData.keys())
keyobj=empData.keys()
list4=list(keyobj)
print(list4)

keyobj=empData.values()
list5=list(keyobj)
print(list5)

print(sum(list5))


#ITERATIONS

for i in empData:       #list4 can be replacad by empData #i by default traverses the key
    empData[i]+=0.1*empData[i]
    print("Emp ID : ",i," Salary : ",empData[i])
    
