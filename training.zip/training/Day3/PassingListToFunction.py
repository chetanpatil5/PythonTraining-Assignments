
def addition(list1):
    print(list1)
    list1.extend([5,6,7])
    print(list1)

nums=[10,20,30]

addition(nums[:])
