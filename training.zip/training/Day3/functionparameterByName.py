def greet(title, name,*anyname,**z):
    print ("Hello "+title+ " "+name)   
    print ("Lower case string = ",name.lower())
    print(anyname)
    print(z)
#greet("Sangita", "Mrs.")            ##Hello Sangita Mrs.

#greet(name="ABC", title="Mr.") #keyword arguments passing to a function call

#greet(title="Mr.", "NIL")    # "NIL" as normal parameter (non-keyword argument)---this can not be passed after keyword argument
                            #Syntax error

#greet("NIL", title="Mr.")   #TypeError: greet() got multiple values for keyword argument 'title'

#greet("Mr", name="NIL", value =100)#Syntax error

greet("Che","MR.",100,200)
# * variable is a special tuple variable: is capable of capturing excessive nonkeyword arguments
# ** variable is special  dictionary which is capable of capturing excessive keyword arguments
greet("Mr",name="Che",value=100)
#non-default default * **
greet("Mr","Che",99,88,"ABC",value=100)
#non keyword is positional arguments


