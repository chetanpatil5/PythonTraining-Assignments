words=["abc","123","xyz",99,"67a"]
upperwords=[]#['ABC','XYZ']

#List Comprehension

#upperwords=[singleword.upper() for singleword in words if singleword.isalpha()==True]

upperwords=[singleword.upper() for singleword in words if type(singleword)==str and singleword.isalpha()]
print(words)
print(upperwords)
