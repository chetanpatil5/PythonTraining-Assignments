"""
Sequence type: Tuple
"""
#tupple of mixed elements
t1=(123,"ABC",3.142)
print("t1 =  ",t1)
print("type of t1 =  ",type(t1))
print("id of t1 =  ",id(t1))
print("First Element = ",t1[0])
print("Type of First Element = ",type(t1[0]))
print("Last Element = ",t1[-1])
print("Type of Last Element = ",type(t1[-1]))
print("t1.index(3.142)  = ",t1.index(3.142))
#print("t1.index(9999)  = ",t1.index(9999)) #ValueError: tuple.index(x): x not in tuple


#can tupple contain one of the element 0f list??- YES
t2=(123,"ABC",3.142,[2,"XYZ"])
print(t2)
t2[3].extend([55,"inside"])
print(t2)

t2[3].pop(2)
print(t2)
