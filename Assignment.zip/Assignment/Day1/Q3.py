inputstr=input("Enter the String : ")
if inputstr.isupper():
    print("The Given String is a UpperCase.")
elif inputstr.islower():
    print("The Given String is a LowerCase.")
else:
    print("The Given String is a Mixed String.")
