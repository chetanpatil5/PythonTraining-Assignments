
def func1():
    global b
    a=-1
    b=10

a="One"
b="Two"

func1()
a="ONEONE"
print(a)
print(b)
