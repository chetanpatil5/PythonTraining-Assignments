"""
2.	Covert all words from a list to titlecase using List comprehension

"""

list1=["pune","nashik","nagpur","chandigarh","mumbai"]
list1=[i[0].upper()+i[1:].lower() for i in list1]
print(list1)
