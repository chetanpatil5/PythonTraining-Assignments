sum1=0

list1=[5,7,9,11]

for i in range(0,len(list1)):
    sum1+=list1[i]

print("Sum of the elements of list is : ",sum1)
