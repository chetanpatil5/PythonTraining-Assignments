"""
Functions in Python

"""
#Display()#NameError: name 'display' is not defined
def Display():  #Function Definition 
    print("In Display Function..............")

def Add(num1,num2=3.556):
    return num1+num2
Display()   #calling a function
result=Display()
print(result)

if result=='None':
    print("HIIII")
else:
    print("No Hiii")

result=Add(100,200.2)
print(result)

result=Add(100)
print(result)


"""
def Add(num1=0,num2):
    return num1+num2
    #Syntax Error
"""


