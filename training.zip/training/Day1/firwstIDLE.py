print("Hello World")

num1=100
if num1==100:
    print("Hello in num1")
    print("num1: ",num1)
elif num1==22:print("elif block")
else:print('else')

#print(x)  #NameError

