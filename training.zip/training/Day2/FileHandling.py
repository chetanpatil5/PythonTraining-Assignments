"""
File Handling

"""

fin=open("Data.txt","r")    #r-read w-write a-append rb wb ab r+
#print(dir())

line=fin.readline()
print(line)

line=fin.readline()
print(line)

line=fin.readline()
print(line)

line=fin.read(4)
print(line)

line=fin.readline()
print(line)
fin.close()


fout=open("target.txt","w")
fout.writelines("Hello Chetan")
fout.writelines("I skipped Above line")
fout.close()
